A simple way to distribute a bundle of files in one binary.
